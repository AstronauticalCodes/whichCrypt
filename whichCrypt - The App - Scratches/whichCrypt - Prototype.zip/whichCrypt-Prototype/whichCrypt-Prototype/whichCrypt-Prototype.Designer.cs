﻿namespace whichCrypt_Prototype
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ModelSelectorLabel = new Label();
            SelectedModelLabel = new Label();
            ModelSelector = new ComboBox();
            SelectedModelDisplayer = new Label();
            inputHashLabel = new Label();
            InputHash = new TextBox();
            SubmitButton = new Demo1.ButtonTrial();
            SuspendLayout();
            // 
            // ModelSelectorLabel
            // 
            ModelSelectorLabel.AutoSize = true;
            ModelSelectorLabel.Location = new Point(203, 119);
            ModelSelectorLabel.Name = "ModelSelectorLabel";
            ModelSelectorLabel.Size = new Size(84, 15);
            ModelSelectorLabel.TabIndex = 0;
            ModelSelectorLabel.Text = "Select a Model";
            // 
            // SelectedModelLabel
            // 
            SelectedModelLabel.AutoSize = true;
            SelectedModelLabel.Location = new Point(203, 163);
            SelectedModelLabel.Name = "SelectedModelLabel";
            SelectedModelLabel.Size = new Size(97, 15);
            SelectedModelLabel.TabIndex = 1;
            SelectedModelLabel.Text = "Selected Model : ";
            // 
            // ModelSelector
            // 
            ModelSelector.DropDownStyle = ComboBoxStyle.DropDownList;
            ModelSelector.FormattingEnabled = true;
            ModelSelector.Items.AddRange(new object[] { "RFC0", "RFC1", "RFC2", "RFC3", "RFC4", "RFC5", "RFC6", "RFC7", "RFC8", "RFC9", "RFC10", "RFC11", "RFC12", "RFC13", "RFC14", "RFC15", "RFC16", "RFC17", "RFC18", "RFC19", "RFC20", "RFC21", "RFC22", "RFC23", "RFC24", "RFC25" });
            ModelSelector.Location = new Point(326, 111);
            ModelSelector.Name = "ModelSelector";
            ModelSelector.Size = new Size(241, 23);
            ModelSelector.TabIndex = 2;
            ModelSelector.SelectedIndexChanged += ModelSelector_SelectedIndexChanged;
            // 
            // SelectedModelDisplayer
            // 
            SelectedModelDisplayer.AutoSize = true;
            SelectedModelDisplayer.Location = new Point(326, 163);
            SelectedModelDisplayer.Name = "SelectedModelDisplayer";
            SelectedModelDisplayer.Size = new Size(38, 15);
            SelectedModelDisplayer.TabIndex = 3;
            SelectedModelDisplayer.Text = "label3";
            // 
            // inputHashLabel
            // 
            inputHashLabel.AutoSize = true;
            inputHashLabel.Location = new Point(203, 204);
            inputHashLabel.Name = "inputHashLabel";
            inputHashLabel.Size = new Size(100, 15);
            inputHashLabel.TabIndex = 4;
            inputHashLabel.Text = "Enter Your Hash : ";
            // 
            // InputHash
            // 
            InputHash.Location = new Point(326, 201);
            InputHash.Name = "InputHash";
            InputHash.Size = new Size(241, 23);
            InputHash.TabIndex = 5;
            // 
            // SubmitButton
            // 
            SubmitButton.BackColor = Color.MediumSlateBlue;
            SubmitButton.FlatAppearance.BorderSize = 0;
            SubmitButton.FlatStyle = FlatStyle.Flat;
            SubmitButton.ForeColor = Color.White;
            SubmitButton.Location = new Point(326, 264);
            SubmitButton.Name = "SubmitButton";
            SubmitButton.Size = new Size(150, 40);
            SubmitButton.TabIndex = 6;
            SubmitButton.Text = "Test for Algorithm";
            SubmitButton.UseVisualStyleBackColor = false;
            SubmitButton.Click += SubmitButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(SubmitButton);
            Controls.Add(InputHash);
            Controls.Add(inputHashLabel);
            Controls.Add(SelectedModelDisplayer);
            Controls.Add(ModelSelector);
            Controls.Add(SelectedModelLabel);
            Controls.Add(ModelSelectorLabel);
            Name = "Form1";
            Text = "whichCrypt-Prototype";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label ModelSelectorLabel;
        private Label SelectedModelLabel;
        private ComboBox ModelSelector;
        private Label SelectedModelDisplayer;
        private Label inputHashLabel;
        private TextBox InputHash;
        private Demo1.ButtonTrial SubmitButton;
    }
}
