using static System.Net.Mime.MediaTypeNames;
using System;
using System.IO;
using System.Text.Json;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace whichCrypt_Prototype
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class JsonHash
        {
            public string CipherText { get; set; }
        }

        public class JsonModel
        {
            public string Model { get; set; }
        }

        public class JsonPrediction
        {
            public Dictionary<string, Dictionary<string, string>> Data { get; set; }
        }
        class HashChecker //To check the Hash of JsonFile
        {
            static void Hello()
            {
                string jsonFilePath = "PYtoCS2.json";
                string hashFilePath = "json_hash.txt";

                // Calculate hash
                string currentHash = CalculateMD5Hash(jsonFilePath);

                // Read stored hash
                string storedHash = File.ReadAllText(hashFilePath);

                // Compare hashes
                if (currentHash != storedHash)
                {
                    // Update stored hash
                    File.WriteAllText(hashFilePath, currentHash);
                }
                else
                {
                    Console.WriteLine("JSON file has not changed.");
                }
            }

            static string CalculateMD5Hash(string filePath)
            {
                using (var md5 = MD5.Create())
                using (var stream = File.OpenRead(filePath))
                {
                    return BitConverter.ToString(md5.ComputeHash(stream)).Replace("-", string.Empty);
                }
            }
        }

        public void ModelSelector_SelectedIndexChanged(object sender, EventArgs e)
        {
            SelectedModelDisplayer.Text = ModelSelector.Text;
            string userModel = SelectedModelDisplayer.Text;
        }

        public void SubmitButton_Click(object sender, EventArgs e)
        {
            string userhash = InputHash.Text;
            //MessageBox.Show(InputHash.Text);
        }
    }
}
